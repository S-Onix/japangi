package japangi;

public interface TicketMachine {
	public void selectMenu();
	public void calculateMenu();
}

package ui;

import java.awt.Color;

import javax.swing.JPanel;

public class ResetPanel extends JPanel {

	/**
	 * Create the panel.
	 */
	public ResetPanel() {
		this.setBackground(Color.BLUE);
	}

}

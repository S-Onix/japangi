package ui;

import java.awt.Color;

import javax.swing.JPanel;

public class PayPanel extends JPanel {

	/**
	 * Create the panel.
	 */
	public PayPanel() {
		this.setBackground(Color.black);
	}

}
